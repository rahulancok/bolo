#!/bin/bash

POOL=de.karlsen.herominers.com:1195
WALLET=karlsen:qq329hhevm6awytkr35lpeh384aty4u5kkxvlwfedjt9ee5zwx3gw9hj0k8xc.lolMinerWorker

./lolMiner --algo KARLSEN --pool $POOL --user $WALLET $@

